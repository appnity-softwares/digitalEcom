import React from 'react';
import FAQSection from '../components/FAQSection';

const FAQ = () => {
    return (
        <div className="pt-20">
            <FAQSection />
        </div>
    );
};

export default FAQ;
